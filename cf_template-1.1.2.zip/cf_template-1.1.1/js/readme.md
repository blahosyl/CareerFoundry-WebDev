Drop your JavaScript files inside this folder.

This readme file can be deleted, though.
