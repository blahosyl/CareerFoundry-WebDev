Drop your image inside this folder.

This readme file can be deleted, though.
