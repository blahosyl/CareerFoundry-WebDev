Drop your CSS files inside this folder.

This readme file can be deleted, though. 
